
// TODO: Auto-generated Javadoc
/**
 * The Class Autonomous.
 */
public class Autonomous extends Simulated{
	
	/**
	 * Instantiates a new autonomous.
	 *
	 * @param name the name
	 * @param sym the sym
	 * @param x the x
	 * @param y the y
	 */
	Autonomous(String name,char sym, int x, int y){
		super(name,sym,x,y);
		super.moveable = true;

	}

	/**
	 * Step.
	 */
	public void step(){
		int vertOrHor = (int)Math.floor((Math.random()*2));
		//will be vertical
		if(vertOrHor == 1){
			int direction = (int)Math.floor((Math.random()*2));
			if(direction == 1){
				//go up
				this.insideOf.moveSimulated(this,1);
			}
			else{
				//go down
				this.insideOf.moveSimulated(this,3);
			}
		}
		else{
			int direction = (int)Math.floor((Math.random()*2));
			if(direction == 1){
				//go right
				this.insideOf.moveSimulated(this,2);
			}
			else{
				//go left
				this.insideOf.moveSimulated(this,4);
			}
		}
	}
}
