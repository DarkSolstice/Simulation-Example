
// TODO: Auto-generated Javadoc
/**
 * The Class Simulated.
 */
public class Simulated {
	
	/** The inside of. */
	protected World insideOf;
	
	/** The loc Y. */
	protected int locX,locY;
	
	/** The name. */
	protected String name;
	
	/** The symbol. */
	protected char symbol;
	
	/** The moveable. */
	protected boolean moveable;
	
	/**
	 * Instantiates a new simulated.
	 *
	 * @param name the name
	 * @param sym the sym
	 * @param x the x
	 * @param y the y
	 */
	protected Simulated(String name,char sym, int x, int y){
		this.name = name;
		this.symbol = sym;
		this.locX = x;
		this.locY = y;
	}
	
	/**
	 * Gets the token.
	 *
	 * @return the token
	 */
	public char getToken(){
		return this.symbol;
	};
	
	/**
	 * Checks if is moveable.
	 *
	 * @return true, if is moveable
	 */
	public boolean isMoveable(){
		return this.moveable;
	}
	
	/**
	 * Gets the location X.
	 *
	 * @return the location X
	 */
	public int getLocationX(){
		return this.locX;
	}
	
	/**
	 * Gets the location Y.
	 *
	 * @return the location Y
	 */
	public int getLocationY(){
		return this.locY;
	}
	
	/**
	 * Sets the world.
	 *
	 * @param myWorld the new world
	 */
	public void setWorld(World myWorld){
		insideOf = myWorld;
	}
	
	/**
	 * Update location.
	 *
	 * @param x the x
	 * @param y the y
	 */
	public void updateLocation(int x, int y){
		this.locX = x;
		this.locY = y;
	}
	
	/**
	 * Gets the name.
	 *
	 * @return the name
	 */
	public String getName(){
		return this.name;
	}
}
