
// TODO: Auto-generated Javadoc
/**
 * The Class Immovable.
 */
public class Immovable extends Simulated{
	
	/**
	 * Instantiates a new immovable.
	 *
	 * @param name the name
	 * @param sym the sym
	 * @param x the x
	 * @param y the y
	 */
	Immovable(String name,char sym, int x, int y){
		super(name,sym,x,y);
		super.moveable = false;

	}


}
