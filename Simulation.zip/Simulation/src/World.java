
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.*;
import java.util.ArrayList;
import javax.swing.*;
import javax.swing.border.LineBorder;
import javax.swing.text.*;

/**
 * The Class World.
 */
public class World
{
	/** The width. */
	private int height,width;
	
	/** The cells. */
	private Simulated[][] cells;
	
	/** The textfields. */
	private JTextArea[][] textfields;
	
	/** The autonomous. */
	private ArrayList<Autonomous> autonomous = new ArrayList<Autonomous>();
	
	/** The logging field. */
	private JTextPane loggingField;
	
	private int movers = 0;
	private int autoers = 0;
	private int nomovers = 0;
	private int iterationCount = 1;
	
	/**
	 * Instantiates a new world. This will create a GUI to view the state and a log which tells you what happened
	 *
	 * @param width the width
	 * @param height the height
	 */
	World(int width,int height){
		cells = new Simulated[height][width];
		textfields = new JTextArea[height][width];
		this.height = height;
		this.width = width;
		
		JFrame main = new JFrame("Simulation Window");
		main.addWindowListener(new WindowAdapter(){
			@Override
            public void windowClosing(WindowEvent e)
            {
                Simulator.main(null);
                e.getWindow().dispose();
            }
		});
			
		//creation of all needed panels
		JPanel worldView = new JPanel();
		JPanel controller_Top = new JPanel();
		JPanel bottomPart = new JPanel();
		JPanel objectAdder = new JPanel();
		JPanel choices = new JPanel();
		JPanel position = new JPanel();
		
		//chechbox needed for selection
		JCheckBox moveableCheck = new JCheckBox("Moveable",false);
		JCheckBox immoveableCheck = new JCheckBox("Immovable",false);
		JCheckBox autonomousCheck = new JCheckBox("Autonomous",false);
		
		//centering for beauty
		moveableCheck.setHorizontalAlignment(JLabel.CENTER);
		immoveableCheck.setHorizontalAlignment(JLabel.CENTER);
		autonomousCheck.setHorizontalAlignment(JLabel.CENTER);
		
		//non anonymous textFields need to retrieve info later
		JTextField yPosition = new JTextField();
		JTextField xPosition = new JTextField();
		
		
		//action listener on checkboxes to make sure only one is selected at a time
		moveableCheck.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e) {
				immoveableCheck.setSelected(false);
				autonomousCheck.setSelected(false);
			}		
		});
		immoveableCheck.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e) {
				moveableCheck.setSelected(false);
				autonomousCheck.setSelected(false);
			}		
		});
		autonomousCheck.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e) {
				immoveableCheck.setSelected(false);
				moveableCheck.setSelected(false);
				
			}		
		});
		
		//setup of all layout of building is followed in this manner
		main.setLayout(new BorderLayout());
		worldView.setLayout(new GridLayout(width,height));
		controller_Top.setLayout(new GridLayout(1,2));
		bottomPart.setLayout(new GridLayout(1,2));
		objectAdder.setLayout(new BorderLayout());
		choices.setLayout(new GridLayout(1,3));
		position.setLayout(new GridLayout(1,4));
		
		//worldview building
		//inital adding of the text area for displaying the world in the center
		for(int y = 0; y<height; y++){
			for(int x = 0; x<width; x++){
				JTextArea text = new JTextArea();
				worldView.add(text);
				text.setBorder(new LineBorder(Color.WHITE,1));
				text.setEditable(false);
				text.setBackground(Color.BLACK);
				textfields[y][x] = text;
			}
		}
		worldView.setPreferredSize(new Dimension(width*80,height*30));
		
		//controller building
		//add button at top Controller for iterating step by step
		JButton iterator = new JButton("Next Step");
		JButton oneHundred = new JButton("100x");
		iterator.addActionListener(new
				ActionListener()
				{
					public void actionPerformed(ActionEvent event)
					{
						step();
						display();
				}	
		});
		controller_Top.add(iterator);
		oneHundred.addActionListener(new
				ActionListener()
				{
					public void actionPerformed(ActionEvent event)
					{
						int temp = iterationCount;
						for(int i = temp; i<temp+100; i++){
							step();
							display();
						}		
				}	
		});
		controller_Top.add(oneHundred);
		
		//Bottompart building
		//logging area bottom left of ui window
		JTextPane logText = new JTextPane();
		logText.addStyle("Main", null);
		logText.setEditable(false);
		JScrollPane temp = new JScrollPane(logText);
		logText.setPreferredSize(new Dimension(200,100));
		temp.setPreferredSize(new Dimension(10,100));
		bottomPart.add(temp);
		loggingField = logText;
		
		
		//adding all component for the object adder bottom right corner of ui
		//adding checkbox to make selection of simulated object to add
		choices.add(moveableCheck);
		choices.add(immoveableCheck);
		choices.add(autonomousCheck);
		objectAdder.add(choices, BorderLayout.CENTER);
	
		//adding position chooser
		position.add(new JTextArea("Choose X:"));
		((JTextArea)(position.getComponent(0))).setEditable(false);
		position.add(xPosition);
		position.add(new JTextArea("Choose Y:"));
		((JTextArea)(position.getComponent(2))).setEditable(false);
		position.add(yPosition);
		objectAdder.add(position,BorderLayout.NORTH);
		
		
		//adding button to object maker
		JButton adder = new JButton("Add");
		//important anonymous actionListener to handle the adding of objects
		adder.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent e) {
				int x =-1;
				int y =-1;
				//checks to see if ints are entered
				try{
					if(Integer.parseInt(xPosition.getText())>=0 && Integer.parseInt(xPosition.getText())<width){
						x = Integer.parseInt(xPosition.getText());
					}
					if(Integer.parseInt(yPosition.getText())>=0 && Integer.parseInt(yPosition.getText())<height){
						y = Integer.parseInt(yPosition.getText());
					}
				}
				catch(Exception e1){
					addActionToLog("Enter an integer in this field.\n",-1);
				}
				try{
					//adds the correct object depending on selected one
					if(moveableCheck.isSelected()){
						movers++;
						add(new Moveable("mover"+ movers,'M',x,y));
						addActionToLog("Added mover"+movers+" to ("+x+","+y+")\n",2);
					}
					if(immoveableCheck.isSelected()){
						nomovers++;
						add(new Immovable("nomover"+ nomovers,'N',x,y));
						addActionToLog("Added nomover"+nomovers+" to ("+x+","+y+")\n",3);
					}
					if(autonomousCheck.isSelected()){
						autoers++;
						add(new Autonomous("auto"+ autoers,'A',x,y));
						addActionToLog("Added auto"+autoers+" to ("+x+","+y+")\n",1);
					}
					display();
				}
				catch(Exception e2){
					addActionToLog("Failed to add Desired Object. "+ e2.getMessage()+"\n",-1);
				}
			}
			
		});
		objectAdder.add(adder,BorderLayout.SOUTH);
		
		//finally add the completed object adder to the window
		bottomPart.add(objectAdder);
		
		//add all three parts to the main window
		main.add(worldView, BorderLayout.CENTER);
		main.add(bottomPart, BorderLayout.SOUTH);
		main.add(controller_Top, BorderLayout.NORTH);
		
		//finalize and make visible
		main.pack();
		main.setLocationRelativeTo(null);
		main.setVisible(true);
		
		
	}
	
	/**
	 * Adds the simulated objects to the world if the room isn't occupied
	 *
	 * @param sim the sim
	 * @throws Exception the exception
	 */
	void add(Simulated sim) throws Exception {
		if(sim.getLocationX()>=0 && sim.getLocationY()>=0 && sim.getLocationX()<=width && sim.getLocationY()<=height){
			
			if(cells[sim.getLocationY()][sim.getLocationX()] == null){
				//put simulated object inside the cells matrix
				cells[sim.getLocationY()][sim.getLocationX()] = sim;
				//link it to the world
				sim.setWorld(this);
				//add it to an arraylist of only autonomous if it is
				if(sim instanceof Autonomous){
					autonomous.add((Autonomous)sim);
				}
			}
			else{
				throw new Exception("Space is already occupied.");
			}
		}
		else{
			throw new Exception("Location not inside world.");
		}
		
	}
	
	/**
	 * Step that runs all the autonomous object for one iteration
	 */
	void step(){
		addActionToLog("Iteration "+iterationCount+":\n", 3);
		iterationCount++;
		for (int i = 0; i < autonomous.size(); i++) {
			(autonomous.get(i)).step();
		}
	}
	
	/**
	 * Display. Updates the GUI to show the current world state.
	 */
	void display(){
		for(int i = 0; i<height;i++){
			for(int j=0; j<width;j++){
				if(cells[i][j]!= null){
					String input = cells[i][j].getName() +"(" + String.valueOf(cells[i][j].getToken()+")");
					textfields[i][j].setText(input);
					if(cells[i][j] instanceof Autonomous){
						textfields[i][j].setBackground(new Color(84,188,50));
					}
					if(cells[i][j] instanceof Moveable){
						textfields[i][j].setBackground(new Color(50,0,255));
					}
					if(cells[i][j] instanceof Immovable){
						textfields[i][j].setBackground(Color.WHITE);
					}
				}
				else{

					textfields[i][j].setBackground(new Color(123,123,123));
				}
			}
		}
	}
	
	/**
	 * Move simulated object in a certain direction
	 *
	 * @param sim the sim
	 * @param direction the direction
	 */
	public void moveSimulated(Simulated sim,int direction){
		if(canBeMoved(sim,direction)){
			Simulated initial = sim;
			Simulated temporary = null;
			switch(direction){
		    //going up
				case 1:{	
					//delete him at start we have copy
					cells[sim.getLocationY()][sim.getLocationX()] = null;
					for(int i = sim.getLocationY()-1;i>=0;i-- ){
						temporary = cells[i][sim.getLocationX()];
						//replace the new location with the new autonomous; staying in the same row
						cells[i][sim.getLocationX()] = initial;
						if(initial instanceof Autonomous){
							addActionToLog(initial.name+" has moved up \n", 1);
						}
						else{
							addActionToLog(initial.name+" has moved up \n", 2);
						}
						//update its location 
						initial.updateLocation(initial.getLocationX(), initial.getLocationY()-1);
						initial = temporary;
						if(temporary == null){
		
							break;
						}
					}
					break;
				}
				//going right
				case 2:{
					cells[sim.getLocationY()][sim.getLocationX()] = null;
					for(int i = sim.getLocationX()+1;i<width;i++ ){
						temporary = cells[sim.getLocationY()][i];
						//replace the new location with the new autonomous staying in the same column
						cells[sim.getLocationY()][i] = initial;
						if(initial instanceof Autonomous){
							addActionToLog(initial.name+" has moved right \n", 1);
						}
						else{
							addActionToLog(initial.name+" has moved right \n", 2);
						}
						initial.updateLocation(initial.getLocationX()+1, initial.getLocationY());
						initial = temporary;
						if(temporary == null){
							break;
						}
					}
					break;
				}
				//going down
				case 3:{	
					cells[sim.getLocationY()][sim.getLocationX()] = null;
					for(int i = sim.getLocationY()+1;i<height;i++ ){
						temporary = cells[i][sim.getLocationX()];
						//replace the new location with the new autonomous; staying in the same row
						cells[i][sim.getLocationX()] = initial;
						if(initial instanceof Autonomous){
							addActionToLog(initial.name+" has moved down \n", 1);
						}
						else{
							addActionToLog(initial.name+" has moved down \n", 2);
						}
						initial.updateLocation(initial.getLocationX(), initial.getLocationY()+1);
						initial = temporary;
						if(temporary == null){
							break;
						}
					}
					break;
				}
				//going left
				case 4:{
					cells[sim.getLocationY()][sim.getLocationX()] = null;
					for(int i = sim.getLocationX()-1;i>=0;i-- ){
						temporary = cells[sim.getLocationY()][i];
						//replace the new location with the new autonomous staying in the same column
						cells[sim.getLocationY()][i] = initial;
						if(initial instanceof Autonomous){
							addActionToLog(initial.name+" has moved left \n", 1);
						}
						else{
							addActionToLog(initial.name+" has moved left \n", 2);
						}
						initial.updateLocation(initial.getLocationX()-1, initial.getLocationY());
						initial = temporary;
						if(temporary == null){

							break;
						}
					}
					break;
				}
			}
			
		}
	}
	
	/**
	 * Check if the direction has a free space to be moved
	 * walls (end of 2D array) and immovable will block
	 *
	 * @param sim the simulated Object
	 * @param direction of the checked movement
	 * @return true, if its possible to move
	 */
	private boolean canBeMoved(Simulated sim, int direction){
		boolean returnValue = false;
		switch(direction){
		    //going up
			case 1:{	
				for(int i = sim.getLocationY()-1;i>=0; i--){
					//found an available space
					if(cells[i][sim.getLocationX()] == null){
						returnValue = true;break;
					}
					//hit an immovable object
					if((cells[i][sim.getLocationX()]).isMoveable()==false){
						returnValue = false;break;
					}
				}
				break;
				//if it ends here the avlue is already false and we hit the top
			}
			//going right
			case 2:{
				for(int i = sim.getLocationX()+1;i<width;i++ ){
					//found an available space
					if(cells[sim.getLocationY()][i] == null){
						returnValue = true;break;
					}
					//hit an immovable object
					if((cells[sim.getLocationY()][i]).isMoveable()==false){
						returnValue = false;break;
					}
				}
				break;
				//if it ends here the avlue is already false and we hit the right side
			}
			//going down
			case 3:{	
				for(int i = sim.getLocationY()+1;i<height;i++ ){
					//found an available space
					if(cells[i][sim.getLocationX()] == null){
						returnValue = true;break;
					}
					//hit an immovable object
					if((cells[i][sim.getLocationX()]).isMoveable()==false){
						returnValue = false;break;
					}
				}
				break;
				//if it ends here the value is already false and we hit the bottom
			}
			//going left
			case 4:{
				for(int i = sim.getLocationX()-1;i>=0;i-- ){
					//found an available space
					if(cells[sim.getLocationY()][i] == null){
						returnValue = true;break;
					}
					//hit an immovable object
					if((cells[sim.getLocationY()][i]).isMoveable()==false){
						returnValue = false;break;
					}
				}
				//if it ends here the avlue is already false and we hit the left side
				break;
			}
		}
		return returnValue;
	}
	
	/**
	 * Adds the action to log.
	 *
	 * @param action the action
	 */
	private void addActionToLog(String action, int whoActioned){
		Style variantStyle = loggingField.getStyle("Main");
		if(whoActioned>=-1 && whoActioned<=3){
			try{
				switch(whoActioned){
					//Error Happened (red)
					case -1:{
						StyleConstants.setForeground(variantStyle, new Color(255,0,0));
						break;
					}
					//actions related to autonomous (Green)
					case 1:{
						StyleConstants.setForeground(variantStyle, new Color(84,188,50));
						break;
					}
					//actions related to movers (blue)
					case 2:{
						StyleConstants.setForeground(variantStyle, new Color(50,0,255));
						break;
					}
					//normal actions
					case 3:{
						StyleConstants.setForeground(variantStyle, Color.BLACK);
						break;
					}
				}
				//set appropriate color
				loggingField.getStyledDocument().insertString(loggingField.getStyledDocument().getLength(),action, variantStyle);
				}
			catch(Exception a){
				
			}
		}
		
	}
}
