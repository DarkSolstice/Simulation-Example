import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.*;

import javax.swing.*;

// TODO: Auto-generated Javadoc
/**
 * The Class Simulator.
 */
public class Simulator {

	/**
	 * The main method.
	 *
	 * @param args the arguments
	 */
	public static void main(String[] args) {
		
		final JDialog startUp = new JDialog();
		JPanel sizeSelector = new JPanel();
		
		startUp.setLayout(new GridLayout(2,1));
		
		sizeSelector.setLayout(new GridLayout(2,2));
		
		
		JTextField yPosition = new JTextField();
		JTextField xPosition = new JTextField();
		
		sizeSelector.add(new JTextArea("Choose width of world:"));
		((JTextArea)(sizeSelector.getComponent(0))).setEditable(false);
		sizeSelector.add(xPosition);
		sizeSelector.add(new JTextArea("Choose height of world:"));
		((JTextArea)(sizeSelector.getComponent(2))).setEditable(false);
		sizeSelector.add(yPosition);

		JButton starter = new JButton("Start");
		starter.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent e) {
				//create a world with the given size
				try{
					//run the class for world which has the integrated UI coding
					World world = new World(Integer.parseInt(xPosition.getText()),Integer.parseInt(yPosition.getText()));
					//hide the startup window
					startUp.setVisible(false);
				}
				catch(Exception e1){
					System.out.println(e1.getMessage());
				}
				
			}
			
		});
		
		
		startUp.add(sizeSelector);
		startUp.add(starter);
		
		startUp.pack();
		startUp.setLocationRelativeTo(null);
		startUp.setVisible(true);
	
	}

}
