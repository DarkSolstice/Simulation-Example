
// TODO: Auto-generated Javadoc
/**
 * The Class Moveable.
 */
public class Moveable extends Simulated{
	
	/**
	 * Instantiates a new moveable.
	 *
	 * @param name the name
	 * @param sym the sym
	 * @param x the x
	 * @param y the y
	 */
	Moveable(String name,char sym, int x, int y){
		super(name,sym,x,y);
		super.moveable = true;

	}
}
